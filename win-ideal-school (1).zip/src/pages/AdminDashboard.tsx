import React, { useState, useEffect } from "react";
import { useAuth } from "../context/AuthContext";
import {
  Plus,
  Edit2,
  Trash2,
  Search,
  X,
  Settings,
  Users,
  BookOpen,
  RotateCw,
  RotateCcw,
  ZoomIn,
  ZoomOut,
  Maximize,
  Eye,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import Cropper, { Area, Point } from "react-easy-crop";
import getCroppedImg from "../utils/cropImage";

type Subject = {
  id: number;
  name: string;
};

type StudentScore = {
  subject_id?: number;
  subjectName: string;
  score: number;
  total_marks: number;
};

type Student = {
  id: number;
  name: string;
  rollNumber: string;
  grade: string;
  section: string;
  phone: string;
  address: string;
  photo?: string;
  scores: StudentScore[];
};

export default function AdminDashboard() {
  const { user } = useAuth();
  const [students, setStudents] = useState<Student[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filter, setFilter] = useState<"all" | "pass" | "fail">("all");
  const [activeTab, setActiveTab] = useState<
    "students" | "subjects" | "settings"
  >("students");
  const [settings, setSettings] = useState({
    school_address: "",
    school_phone: "",
    school_website: "",
    school_whatsapp: "",
  });
  const [savingSettings, setSavingSettings] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSubjectModalOpen, setIsSubjectModalOpen] = useState(false);
  const [isPhotoEditorOpen, setIsPhotoEditorOpen] = useState(false);
  const [tempPhoto, setTempPhoto] = useState<string | null>(null);
  const [crop, setCrop] = useState<Point>({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [croppedAreaPixels, setCroppedAreaPixels] = useState<Area | null>(null);

  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [viewingStudent, setViewingStudent] = useState<Student | null>(null);
  const [editingSubject, setEditingSubject] = useState<Subject | null>(null);
  const [subjectName, setSubjectName] = useState("");
  const [formData, setFormData] = useState({
    name: "",
    rollNumber: "",
    grade: "",
    section: "",
    phone: "",
    address: "",
    photo: "",
    scores: [] as StudentScore[],
  });

  useEffect(() => {
    fetchSubjects();
    fetchSettings();
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      fetchStudents(searchTerm);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchTerm]);

  const fetchSubjects = async () => {
    try {
      const res = await fetch("/api/subjects");
      const data = await res.json();
      setSubjects(data);
    } catch (error) {
      console.error("Failed to fetch subjects", error);
    }
  };

  const fetchSettings = async () => {
    try {
      const res = await fetch("/api/settings");
      const data = await res.json();
      if (data && Object.keys(data).length > 0) {
        setSettings((prev) => ({ ...prev, ...data }));
      }
    } catch (error) {
      console.error("Failed to fetch settings", error);
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingSettings(true);
    try {
      await fetch("/api/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings),
      });
      window.dispatchEvent(new Event("settingsUpdated"));
      alert("Settings saved successfully.");
    } catch (error) {
      console.error("Failed to save settings", error);
      alert("Failed to save settings");
    } finally {
      setSavingSettings(false);
    }
  };

  const fetchStudents = async (search?: string) => {
    try {
      const url = search
        ? `/api/students?search=${encodeURIComponent(search)}`
        : "/api/students";
      const res = await fetch(url);
      const data = await res.json();
      setStudents(data);
    } catch (error) {
      console.error("Failed to fetch students", error);
    }
  };

  const handleOpenModal = (student?: Student) => {
    if (student) {
      setEditingStudent(student);
      setFormData({
        name: student.name,
        rollNumber: student.rollNumber,
        grade: student.grade,
        section: student.section,
        phone: student.phone,
        address: student.address,
        photo: student.photo || "",
        scores: student.scores.map(s => ({ ...s, subjectName: s.subjectName || "" })),
      });
    } else {
      setEditingStudent(null);
      setFormData({
        name: "",
        rollNumber: "",
        grade: "",
        section: "",
        phone: "",
        address: "",
        photo: "",
        scores: subjects.map((s) => ({
          subjectName: s.name,
          score: 0,
          total_marks: 100,
        })),
      });
    }
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingStudent(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingStudent) {
        await fetch(`/api/students/${editingStudent.id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(formData),
        });
      } else {
        await fetch("/api/students", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(formData),
        });
      }
      fetchStudents();
      handleCloseModal();
    } catch (error) {
      console.error("Failed to save student", error);
      alert("Failed to save student. Roll number might already exist.");
    }
  };

  const handleDelete = async (id: number) => {
    if (confirm("Are you sure you want to delete this student?")) {
      try {
        await fetch(`/api/students/${id}`, { method: "DELETE" });
        fetchStudents();
      } catch (error) {
        console.error("Failed to delete student", error);
      }
    }
  };

  const handleSubjectSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingSubject) {
        await fetch(`/api/subjects/${editingSubject.id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name: subjectName }),
        });
      } else {
        await fetch("/api/subjects", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name: subjectName }),
        });
      }
      fetchSubjects();
      setIsSubjectModalOpen(false);
      setSubjectName("");
      setEditingSubject(null);
    } catch (error) {
      console.error("Failed to save subject", error);
    }
  };

  const handleDeleteSubject = async (id: number) => {
    if (
      confirm("Are you sure? This will remove this subject from all students.")
    ) {
      try {
        await fetch(`/api/subjects/${id}`, { method: "DELETE" });
        fetchSubjects();
      } catch (error) {
        console.error("Failed to delete subject", error);
      }
    }
  };

  // Calculate ranks based on average score descending
  const rankedStudents = [...students]
    .sort((a, b) => {
      const avgA =
        a.scores.length > 0
          ? a.scores.reduce((sum, s) => sum + s.score / s.total_marks, 0) /
            a.scores.length
          : 0;
      const avgB =
        b.scores.length > 0
          ? b.scores.reduce((sum, s) => sum + s.score / s.total_marks, 0) /
            b.scores.length
          : 0;
      return avgB - avgA;
    })
    .map((s, index) => ({
      ...s,
      rank: index + 1,
    }));

  const filteredStudents = rankedStudents.filter((s) => {
    const avg =
      s.scores.length > 0
        ? s.scores.reduce((sum, sc) => sum + sc.score / sc.total_marks, 0) /
          s.scores.length
        : 0;
    const isPass = avg >= 0.4; // Assuming 40% average is passing

    if (filter === "pass") return isPass;
    if (filter === "fail") return !isPass;
    return true;
  });

  const onCropComplete = (
    _croppedArea: Area,
    croppedAreaPixels: Area,
  ) => {
    setCroppedAreaPixels(croppedAreaPixels);
  };

  const handleSaveCroppedImage = async () => {
    if (tempPhoto && croppedAreaPixels) {
      try {
        const croppedImage = await getCroppedImg(
          tempPhoto,
          croppedAreaPixels,
          rotation,
        );
        if (croppedImage) {
          // Update local form state
          const updatedFormData = { ...formData, photo: croppedImage };
          setFormData(updatedFormData);
          
          // If we are editing an existing student, save to database immediately
          if (editingStudent) {
            try {
              const res = await fetch(`/api/students/${editingStudent.id}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(updatedFormData),
              });
              if (res.ok) {
                fetchStudents(searchTerm);
                // Also update viewing student if it's the same one
                if (viewingStudent?.id === editingStudent.id) {
                  setViewingStudent({ ...viewingStudent, photo: croppedImage });
                }
              }
            } catch (error) {
              console.error("Failed to auto-save photo to database", error);
            }
          }

          setIsPhotoEditorOpen(false);
          setTempPhoto(null);
          setRotation(0);
          setZoom(1);
        }
      } catch (e) {
        console.error(e);
      }
    }
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setTempPhoto(reader.result as string);
        setIsPhotoEditorOpen(true);
      };
      reader.readAsDataURL(file);
    }
  };

  if (user?.role !== "admin")
    return <div className="p-8 text-center">Access Denied</div>;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 min-h-[calc(100vh-80px-200px)]">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Admin Dashboard</h2>
          <p className="text-sm text-slate-500">
            Manage school records and settings
          </p>
        </div>

        <div className="flex space-x-2 bg-slate-100 p-1 rounded-lg">
          <button
            onClick={() => setActiveTab("students")}
            className={`flex items-center space-x-2 px-4 py-2 text-sm font-medium rounded-md transition-colors ${
              activeTab === "students"
                ? "bg-white text-indigo-700 shadow-sm"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <Users className="h-4 w-4" />
            <span>Students</span>
          </button>
          <button
            onClick={() => setActiveTab("subjects")}
            className={`flex items-center space-x-2 px-4 py-2 text-sm font-medium rounded-md transition-colors ${
              activeTab === "subjects"
                ? "bg-white text-indigo-700 shadow-sm"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <BookOpen className="h-4 w-4" />
            <span>Subjects</span>
          </button>
          <button
            onClick={() => setActiveTab("settings")}
            className={`flex items-center space-x-2 px-4 py-2 text-sm font-medium rounded-md transition-colors ${
              activeTab === "settings"
                ? "bg-white text-indigo-700 shadow-sm"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <Settings className="h-4 w-4" />
            <span>Settings</span>
          </button>
        </div>
      </div>

      {activeTab === "students" ? (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="flex flex-col sm:flex-row justify-between items-center p-4 border-b border-slate-200 bg-slate-50 gap-4">
            <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
              <div className="relative w-full sm:w-64">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-slate-400" />
                </div>
                <input
                  type="text"
                  placeholder="Search by name or roll no..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="block w-full pl-10 pr-3 py-2 border border-slate-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                />
              </div>
              <div className="flex space-x-2 bg-slate-200/50 p-1 rounded-lg">
                <button
                  onClick={() => setFilter("all")}
                  className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
                    filter === "all"
                      ? "bg-white text-indigo-700 shadow-sm"
                      : "text-slate-600 hover:text-slate-900"
                  }`}
                >
                  All Students
                </button>
                <button
                  onClick={() => setFilter("pass")}
                  className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
                    filter === "pass"
                      ? "bg-white text-emerald-700 shadow-sm"
                      : "text-slate-600 hover:text-slate-900"
                  }`}
                >
                  Pass
                </button>
                <button
                  onClick={() => setFilter("fail")}
                  className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
                    filter === "fail"
                      ? "bg-white text-red-700 shadow-sm"
                      : "text-slate-600 hover:text-slate-900"
                  }`}
                >
                  Fail
                </button>
              </div>
            </div>
            <button
              onClick={() => handleOpenModal()}
              className="flex w-full sm:w-auto items-center justify-center space-x-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg transition-colors shadow-sm"
            >
              <Plus className="h-4 w-4" />
              <span>Add Student</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                    Rank
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                    Roll No
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                    Name
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                    Class
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                    Performance (Avg)
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-200">
                {filteredStudents.map((student) => {
                  const avg =
                    student.scores.length > 0
                      ? (student.scores.reduce((sum, sc) => sum + sc.score, 0) /
                          student.scores.reduce(
                            (sum, sc) => sum + sc.total_marks,
                            0,
                          )) *
                        100
                      : 0;
                  const isPass = avg >= 40;
                  return (
                    <tr
                      key={student.id}
                      className="hover:bg-slate-50 transition-colors"
                    >
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-slate-900">
                        #{student.rank}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="h-10 w-10 flex-shrink-0">
                            {student.photo ? (
                              <img
                                className="h-10 w-10 rounded-full object-cover border border-slate-200"
                                src={student.photo}
                                alt=""
                                referrerPolicy="no-referrer"
                              />
                            ) : (
                              <div className="h-10 w-10 rounded-full bg-slate-100 flex items-center justify-center border border-slate-200">
                                <Users className="h-5 w-5 text-slate-400" />
                              </div>
                            )}
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-slate-900">
                              {student.name}
                            </div>
                            <div className="text-xs text-slate-500">
                              {student.rollNumber}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                        Grade {student.grade} - {student.section}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-900 font-medium">
                        {avg.toFixed(1)}%
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm">
                        <span
                          className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${isPass ? "bg-emerald-100 text-emerald-800" : "bg-red-100 text-red-800"}`}
                        >
                          {isPass ? "Pass" : "Fail"}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex justify-end space-x-3">
                          <button
                            onClick={() => setViewingStudent(student)}
                            className="text-slate-400 hover:text-indigo-600 transition-colors"
                            title="View Profile"
                          >
                            <Eye className="h-5 w-5" />
                          </button>
                          <button
                            onClick={() => handleOpenModal(student)}
                            className="text-slate-400 hover:text-indigo-600 transition-colors"
                            title="Edit"
                          >
                            <Edit2 className="h-5 w-5" />
                          </button>
                          <button
                            onClick={() => handleDelete(student.id)}
                            className="text-slate-400 hover:text-red-600 transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="h-5 w-5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
                {filteredStudents.length === 0 && (
                  <tr>
                    <td
                      colSpan={8}
                      className="px-6 py-8 text-center text-sm text-slate-500"
                    >
                      No students found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : activeTab === "subjects" ? (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="flex justify-between items-center p-4 border-b border-slate-200 bg-slate-50">
            <h3 className="text-lg font-bold text-slate-900">
              Manage Subjects
            </h3>
            <button
              onClick={() => {
                setEditingSubject(null);
                setSubjectName("");
                setIsSubjectModalOpen(true);
              }}
              className="flex items-center space-x-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg transition-colors shadow-sm"
            >
              <Plus className="h-4 w-4" />
              <span>Add Subject</span>
            </button>
          </div>
          <div className="p-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {subjects.map((subject) => (
                <div
                  key={subject.id}
                  className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-200"
                >
                  <span className="font-medium text-slate-700">
                    {subject.name}
                  </span>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => {
                        setEditingSubject(subject);
                        setSubjectName(subject.name);
                        setIsSubjectModalOpen(true);
                      }}
                      className="text-indigo-600 hover:text-indigo-900"
                    >
                      <Edit2 className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteSubject(subject.id)}
                      className="text-red-600 hover:text-red-900"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden max-w-2xl">
          <div className="p-6 border-b border-slate-200">
            <h3 className="text-lg font-bold text-slate-900">
              Footer Settings
            </h3>
            <p className="text-sm text-slate-500">
              Update the contact information displayed in the footer.
            </p>
          </div>
          <form onSubmit={handleSaveSettings} className="p-6 space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                School Address
              </label>
              <input
                type="text"
                value={settings.school_address}
                onChange={(e) =>
                  setSettings({ ...settings, school_address: e.target.value })
                }
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Phone Number
              </label>
              <input
                type="text"
                value={settings.school_phone}
                onChange={(e) =>
                  setSettings({ ...settings, school_phone: e.target.value })
                }
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Website
              </label>
              <input
                type="text"
                value={settings.school_website}
                onChange={(e) =>
                  setSettings({ ...settings, school_website: e.target.value })
                }
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                WhatsApp Number
              </label>
              <input
                type="text"
                value={settings.school_whatsapp}
                onChange={(e) =>
                  setSettings({ ...settings, school_whatsapp: e.target.value })
                }
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              />
            </div>
            <div className="pt-4">
              <button
                type="submit"
                disabled={savingSettings}
                className="w-full sm:w-auto px-6 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-lg hover:bg-indigo-700 disabled:opacity-50 transition-colors"
              >
                {savingSettings ? "Saving..." : "Save Settings"}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-xl shadow-xl max-w-md w-full overflow-hidden"
            >
              <div className="flex justify-between items-center p-6 border-b border-slate-100">
                <h3 className="text-lg font-bold text-slate-900">
                  {editingStudent ? "Edit Student" : "Add New Student"}
                </h3>
                <button
                  onClick={handleCloseModal}
                  className="text-slate-400 hover:text-slate-500"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="p-6 space-y-4">
                <div className="flex flex-col items-center mb-6">
                  <div className="relative group">
                    <div className="h-24 w-24 rounded-full bg-slate-100 border-2 border-dashed border-slate-300 flex items-center justify-center overflow-hidden">
                      {formData.photo ? (
                        <img
                          src={formData.photo}
                          alt="Preview"
                          className="h-full w-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <Users className="h-10 w-10 text-slate-300" />
                      )}
                    </div>
                    <label className="absolute inset-0 flex items-center justify-center bg-black/40 text-white opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer rounded-full">
                      <span className="text-xs font-bold">Edit</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handlePhotoUpload}
                      />
                    </label>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-2 uppercase tracking-widest font-bold">
                    Passport Photo
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Full Name
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">
                      Roll Number
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.rollNumber}
                      onChange={(e) =>
                        setFormData({ ...formData, rollNumber: e.target.value })
                      }
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">
                      Phone
                    </label>
                    <input
                      type="text"
                      value={formData.phone}
                      onChange={(e) =>
                        setFormData({ ...formData, phone: e.target.value })
                      }
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">
                      Grade
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.grade}
                      onChange={(e) =>
                        setFormData({ ...formData, grade: e.target.value })
                      }
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">
                      Section
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.section}
                      onChange={(e) =>
                        setFormData({ ...formData, section: e.target.value })
                      }
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                    />
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="block text-sm font-medium text-slate-700">
                      Subject Scores
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        setFormData({
                          ...formData,
                          scores: [
                            ...formData.scores,
                            { subjectName: "", score: 0, total_marks: 100 },
                          ],
                        });
                      }}
                      className="text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center space-x-1"
                    >
                      <Plus className="h-3 w-3" />
                      <span>Add Subject</span>
                    </button>
                  </div>
                  <div className="space-y-3 max-h-60 overflow-y-auto p-3 bg-slate-50 rounded-lg border border-slate-200">
                    {formData.scores.map((score, idx) => (
                      <div key={idx} className="flex items-center space-x-2">
                        <div className="grid grid-cols-3 gap-2 flex-1">
                          <input
                            type="text"
                            placeholder="Subject (e.g. Math)"
                            value={score.subjectName}
                            onChange={(e) => {
                              const newScores = [...formData.scores];
                              newScores[idx].subjectName = e.target.value;
                              setFormData({ ...formData, scores: newScores });
                            }}
                            className="px-2 py-1 border border-slate-300 rounded focus:ring-indigo-500 focus:border-indigo-500 text-sm"
                          />
                          <input
                            type="number"
                            placeholder="Score"
                            value={score.score || ""}
                            onChange={(e) => {
                              const val = parseInt(e.target.value) || 0;
                              const newScores = [...formData.scores];
                              newScores[idx].score = val;
                              setFormData({ ...formData, scores: newScores });
                            }}
                            className="px-2 py-1 border border-slate-300 rounded focus:ring-indigo-500 focus:border-indigo-500 text-sm"
                          />
                          <input
                            type="number"
                            placeholder="Total"
                            value={score.total_marks || 100}
                            onChange={(e) => {
                              const val = parseInt(e.target.value) || 100;
                              const newScores = [...formData.scores];
                              newScores[idx].total_marks = val;
                              setFormData({ ...formData, scores: newScores });
                            }}
                            className="px-2 py-1 border border-slate-300 rounded focus:ring-indigo-500 focus:border-indigo-500 text-sm"
                          />
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            const newScores = formData.scores.filter((_, i) => i !== idx);
                            setFormData({ ...formData, scores: newScores });
                          }}
                          className="text-red-400 hover:text-red-600 p-1"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                    {formData.scores.length === 0 && (
                      <p className="text-center text-xs text-slate-400 py-4">
                        No subjects added. Click "Add Subject" to start.
                      </p>
                    )}
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Address
                  </label>
                  <textarea
                    rows={3}
                    value={formData.address}
                    onChange={(e) =>
                      setFormData({ ...formData, address: e.target.value })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                </div>

                <div className="pt-4 flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={handleCloseModal}
                    className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-lg hover:bg-indigo-700"
                  >
                    Save Student
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Subject Modal */}
      <AnimatePresence>
        {isSubjectModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-xl shadow-xl max-w-sm w-full overflow-hidden"
            >
              <div className="flex justify-between items-center p-6 border-b border-slate-100">
                <h3 className="text-lg font-bold text-slate-900">
                  {editingSubject ? "Edit Subject" : "Add New Subject"}
                </h3>
                <button
                  onClick={() => setIsSubjectModalOpen(false)}
                  className="text-slate-400 hover:text-slate-500"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <form onSubmit={handleSubjectSubmit} className="p-6 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Subject Name
                  </label>
                  <input
                    type="text"
                    required
                    value={subjectName}
                    onChange={(e) => setSubjectName(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                </div>

                <div className="pt-4 flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={() => setIsSubjectModalOpen(false)}
                    className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-lg hover:bg-indigo-700"
                  >
                    Save Subject
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* View Profile Modal */}
      <AnimatePresence>
        {viewingStudent && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full overflow-hidden border border-slate-100"
            >
              <div className="bg-indigo-600 px-8 py-10 text-center text-white relative">
                <button
                  onClick={() => setViewingStudent(null)}
                  className="absolute top-6 right-6 text-white/60 hover:text-white transition-colors"
                >
                  <X className="h-6 w-6" />
                </button>
                <div className="inline-flex items-center justify-center h-32 w-32 rounded-full bg-white/20 backdrop-blur-sm mb-4 overflow-hidden border-4 border-white/30 shadow-lg">
                  {viewingStudent.photo ? (
                    <img
                      src={viewingStudent.photo}
                      alt={viewingStudent.name}
                      className="h-full w-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <Users className="h-16 w-16 text-white" />
                  )}
                </div>
                <h2 className="text-2xl font-bold">{viewingStudent.name}</h2>
                <p className="text-indigo-100 mt-1 font-medium">
                  Roll No: {viewingStudent.rollNumber}
                </p>
              </div>

              <div className="p-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                  <div className="bg-slate-50 rounded-xl p-6 border border-slate-100">
                    <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">
                      Academic Info
                    </h3>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-sm text-slate-500">Grade</span>
                        <span className="text-sm font-bold text-slate-900">
                          {viewingStudent.grade}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-slate-500">Section</span>
                        <span className="text-sm font-bold text-slate-900">
                          {viewingStudent.section}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-slate-50 rounded-xl p-6 border border-slate-100">
                    <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">
                      Contact Info
                    </h3>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-sm text-slate-500">Phone</span>
                        <span className="text-sm font-bold text-slate-900">
                          {viewingStudent.phone || "N/A"}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-slate-500">Address</span>
                        <span className="text-sm font-bold text-slate-900 text-right max-w-[150px] truncate">
                          {viewingStudent.address || "N/A"}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-50 rounded-xl p-6 border border-slate-100">
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">
                    Subject Performance
                  </h3>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                    {viewingStudent.scores.map((s, idx) => (
                      <div key={idx} className="bg-white p-3 rounded-lg border border-slate-200">
                        <p className="text-xs font-bold text-slate-900 truncate">
                          {s.subjectName}
                        </p>
                        <p className="text-sm font-medium text-indigo-600 mt-1">
                          {s.score}/{s.total_marks}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Photo Editor Modal */}
      <AnimatePresence>
        {isPhotoEditorOpen && tempPhoto && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-slate-900 rounded-2xl shadow-2xl max-w-2xl w-full overflow-hidden border border-white/10"
            >
              <div className="flex justify-between items-center p-6 border-b border-white/5">
                <div>
                  <h3 className="text-lg font-bold text-white">Photo Editor</h3>
                  <p className="text-xs text-slate-400">
                    Adjust, zoom, and rotate your passport photo
                  </p>
                </div>
                <button
                  onClick={() => setIsPhotoEditorOpen(false)}
                  className="text-slate-400 hover:text-white transition-colors"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>

              <div className="relative h-96 bg-black">
                <Cropper
                  image={tempPhoto}
                  crop={crop}
                  zoom={zoom}
                  rotation={rotation}
                  aspect={1}
                  onCropChange={setCrop}
                  onCropComplete={onCropComplete}
                  onZoomChange={setZoom}
                  onRotationChange={setRotation}
                />
              </div>

              <div className="p-6 space-y-6 bg-slate-800/50">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Zoom Controls */}
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                        Zoom
                      </span>
                      <span className="text-xs font-mono text-indigo-400">
                        {zoom.toFixed(1)}x
                      </span>
                    </div>
                    <div className="flex items-center space-x-4">
                      <button
                        onClick={() => setZoom(Math.max(1, zoom - 0.1))}
                        className="p-2 rounded-lg bg-slate-700 text-slate-300 hover:bg-slate-600 transition-colors"
                      >
                        <ZoomOut className="h-4 w-4" />
                      </button>
                      <input
                        type="range"
                        value={zoom}
                        min={1}
                        max={3}
                        step={0.1}
                        aria-labelledby="Zoom"
                        onChange={(e) => setZoom(Number(e.target.value))}
                        className="flex-1 accent-indigo-500 h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer"
                      />
                      <button
                        onClick={() => setZoom(Math.min(3, zoom + 0.1))}
                        className="p-2 rounded-lg bg-slate-700 text-slate-300 hover:bg-slate-600 transition-colors"
                      >
                        <ZoomIn className="h-4 w-4" />
                      </button>
                    </div>
                  </div>

                  {/* Rotation Controls */}
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                        Rotation
                      </span>
                      <span className="text-xs font-mono text-indigo-400">
                        {rotation}°
                      </span>
                    </div>
                    <div className="flex items-center space-x-4">
                      <button
                        onClick={() => setRotation((rotation - 90) % 360)}
                        className="p-2 rounded-lg bg-slate-700 text-slate-300 hover:bg-slate-600 transition-colors"
                      >
                        <RotateCcw className="h-4 w-4" />
                      </button>
                      <input
                        type="range"
                        value={rotation}
                        min={0}
                        max={360}
                        step={1}
                        aria-labelledby="Rotation"
                        onChange={(e) => setRotation(Number(e.target.value))}
                        className="flex-1 accent-indigo-500 h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer"
                      />
                      <button
                        onClick={() => setRotation((rotation + 90) % 360)}
                        className="p-2 rounded-lg bg-slate-700 text-slate-300 hover:bg-slate-600 transition-colors"
                      >
                        <RotateCw className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end space-x-3 pt-4 border-t border-white/5">
                  <button
                    onClick={() => setIsPhotoEditorOpen(false)}
                    className="px-6 py-2 text-sm font-bold text-slate-400 hover:text-white transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSaveCroppedImage}
                    className="flex items-center space-x-2 px-8 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-bold rounded-xl transition-all shadow-lg shadow-indigo-500/20"
                  >
                    <Maximize className="h-4 w-4" />
                    <span>Apply Changes</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
