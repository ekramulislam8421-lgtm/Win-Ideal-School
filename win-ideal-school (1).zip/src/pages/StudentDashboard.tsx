import React, { useState, useEffect } from "react";
import { useAuth } from "../context/AuthContext";
import {
  User,
  BookOpen,
  MapPin,
  Phone,
  Hash,
  Award,
  Target,
  CheckCircle2,
  XCircle,
  BarChart3,
  Loader2,
} from "lucide-react";
import { motion } from "motion/react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";

export default function StudentDashboard() {
  const { user } = useAuth();
  const [student, setStudent] = useState<any>(user?.student);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchLatestData = async () => {
      if (user?.student?.id) {
        try {
          const res = await fetch(`/api/students/${user.student.id}`);
          if (res.ok) {
            const data = await res.json();
            setStudent(data);
          }
        } catch (error) {
          console.error("Failed to fetch latest student data", error);
        } finally {
          setLoading(false);
        }
      } else {
        setLoading(false);
      }
    };

    fetchLatestData();
  }, [user?.student?.id]);

  if (user?.role !== "student" || !student) {
    if (loading) {
      return (
        <div className="min-h-[60vh] flex items-center justify-center">
          <Loader2 className="h-8 w-8 text-indigo-600 animate-spin" />
        </div>
      );
    }
    return <div className="p-8 text-center">Access Denied</div>;
  }

  const chartData = student.scores.map((s: any) => ({
    name: s.subjectName,
    percentage: Math.round((s.score / s.total_marks) * 100),
    score: s.score,
    total: s.total_marks,
  }));

  const totalPossible = student.scores.reduce(
    (sum, s) => sum + s.total_marks,
    0,
  );
  const totalObtained = student.scores.reduce((sum, s) => sum + s.score, 0);
  const overallPercentage =
    totalPossible > 0 ? (totalObtained / totalPossible) * 100 : 0;
  const isPass = overallPercentage >= 40;

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 min-h-[calc(100vh-80px-200px)]">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-100"
      >
        <div className="bg-indigo-600 px-8 py-12 text-center text-white relative">
          <div className="absolute top-6 right-6">
            <span
              className={`px-4 py-1.5 inline-flex items-center space-x-2 text-sm font-bold rounded-full shadow-sm ${isPass ? "bg-emerald-400 text-emerald-950" : "bg-red-400 text-red-950"}`}
            >
              {isPass ? (
                <CheckCircle2 className="h-4 w-4" />
              ) : (
                <XCircle className="h-4 w-4" />
              )}
              <span>{isPass ? "PASSED" : "FAILED"}</span>
            </span>
          </div>
          <div className="inline-flex items-center justify-center h-32 w-32 rounded-full bg-white/20 backdrop-blur-sm mb-4 overflow-hidden border-4 border-white/30 shadow-lg">
            {student.photo ? (
              <img
                src={student.photo}
                alt={student.name}
                className="h-full w-full object-cover"
                referrerPolicy="no-referrer"
              />
            ) : (
              <User className="h-16 w-16 text-white" />
            )}
          </div>
          <h2 className="text-3xl font-bold">{student.name}</h2>
          <p className="text-indigo-100 mt-2 font-medium">Student Profile</p>
        </div>

        <div className="p-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
            <div className="lg:col-span-2 bg-slate-50 rounded-xl p-6 border border-slate-100">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider">
                  Subject-wise Performance (%)
                </h3>
                <BarChart3 className="h-5 w-5 text-indigo-500" />
              </div>
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={chartData}
                    margin={{ top: 5, right: 30, left: 0, bottom: 5 }}
                  >
                    <CartesianGrid
                      strokeDasharray="3 3"
                      vertical={false}
                      stroke="#e2e8f0"
                    />
                    <XAxis
                      dataKey="name"
                      axisLine={false}
                      tickLine={false}
                      tick={{ fill: "#64748b", fontSize: 12 }}
                    />
                    <YAxis
                      domain={[0, 100]}
                      axisLine={false}
                      tickLine={false}
                      tick={{ fill: "#64748b", fontSize: 12 }}
                    />
                    <Tooltip
                      cursor={{ fill: "#f1f5f9" }}
                      contentStyle={{
                        borderRadius: "8px",
                        border: "none",
                        boxShadow: "0 4px 6px -1px rgb(0 0 0 / 0.1)",
                      }}
                    />
                    <Bar dataKey="percentage" radius={[4, 4, 0, 0]}>
                      {chartData.map((entry, index) => (
                        <Cell
                          key={`cell-${index}`}
                          fill={entry.percentage >= 40 ? "#6366f1" : "#ef4444"}
                        />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="space-y-6">
              <div className="bg-slate-50 rounded-xl p-6 border border-slate-100">
                <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">
                  Overall Result
                </h3>
                <div className="flex flex-col items-center justify-center py-4">
                  <div className="relative inline-flex items-center justify-center">
                    <svg className="h-32 w-32 transform -rotate-90">
                      <circle
                        className="text-slate-200"
                        strokeWidth="8"
                        stroke="currentColor"
                        fill="transparent"
                        r="58"
                        cx="64"
                        cy="64"
                      />
                      <circle
                        className={isPass ? "text-indigo-600" : "text-red-500"}
                        strokeWidth="8"
                        strokeDasharray={364.4}
                        strokeDashoffset={
                          364.4 - (364.4 * overallPercentage) / 100
                        }
                        strokeLinecap="round"
                        stroke="currentColor"
                        fill="transparent"
                        r="58"
                        cx="64"
                        cy="64"
                      />
                    </svg>
                    <span className="absolute text-2xl font-bold text-slate-900">
                      {Math.round(overallPercentage)}%
                    </span>
                  </div>
                  <div className="mt-4 text-center">
                    <p className="text-sm font-medium text-slate-500">
                      Total Marks Obtained
                    </p>
                    <p className="text-xl font-bold text-slate-900">
                      {totalObtained} / {totalPossible}
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-slate-50 rounded-xl p-6 border border-slate-100">
                <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">
                  Personal Details
                </h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Hash className="h-4 w-4 text-indigo-500" />
                      <span className="text-xs font-medium text-slate-600">
                        Roll No
                      </span>
                    </div>
                    <span className="text-xs font-bold text-slate-900">
                      {student.rollNumber}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <User className="h-4 w-4 text-indigo-500" />
                      <span className="text-xs font-medium text-slate-600">
                        Class
                      </span>
                    </div>
                    <span className="text-xs font-bold text-slate-900">
                      Grade {student.grade}-{student.section}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Phone className="h-4 w-4 text-indigo-500" />
                      <span className="text-xs font-medium text-slate-600">
                        Contact
                      </span>
                    </div>
                    <span className="text-xs font-bold text-slate-900">
                      {student.phone || "N/A"}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-slate-50 rounded-xl p-6 border border-slate-100">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">
              Subject Details
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {student.scores.map((s, idx) => (
                <div
                  key={idx}
                  className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm"
                >
                  <div className="flex justify-between items-start mb-2">
                    <span className="font-bold text-slate-900">
                      {s.subjectName}
                    </span>
                    <span
                      className={`text-xs font-bold px-2 py-0.5 rounded ${s.score / s.total_marks >= 0.4 ? "bg-emerald-100 text-emerald-700" : "bg-red-100 text-red-700"}`}
                    >
                      {Math.round((s.score / s.total_marks) * 100)}%
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-500">Score</span>
                    <span className="font-medium text-slate-700">
                      {s.score} / {s.total_marks}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
