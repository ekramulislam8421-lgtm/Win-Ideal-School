import React from "react";
import { GraduationCap, LogOut } from "lucide-react";
import { useAuth } from "../context/AuthContext";

export default function Header() {
  const { user, logout } = useAuth();

  return (
    <header className="bg-indigo-900 text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <div className="flex items-center space-x-3">
            <div className="bg-white p-2 rounded-full">
              <GraduationCap className="h-8 w-8 text-indigo-900" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight">
                WIN Ideal School
              </h1>
              <p className="text-indigo-200 text-sm font-medium">
                Excellence in Education
              </p>
            </div>
          </div>

          {user && (
            <div className="flex items-center space-x-4">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-medium">
                  {user.role === "admin" ? "Administrator" : user.student?.name}
                </p>
                <p className="text-xs text-indigo-300">
                  {user.role === "admin"
                    ? "Full Access"
                    : `Roll: ${user.student?.rollNumber}`}
                </p>
              </div>
              <button
                onClick={logout}
                className="flex items-center space-x-2 bg-indigo-800 hover:bg-indigo-700 px-4 py-2 rounded-lg transition-colors text-sm font-medium"
              >
                <LogOut className="h-4 w-4" />
                <span>Logout</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
