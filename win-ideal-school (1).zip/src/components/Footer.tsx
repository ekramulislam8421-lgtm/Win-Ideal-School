import React, { useState, useEffect } from "react";
import { MapPin, Phone, Globe, MessageCircle } from "lucide-react";

export default function Footer() {
  const [settings, setSettings] = useState({
    school_address: "123 Education Avenue, Knowledge City, 10001",
    school_phone: "+1 (555) 123-4567",
    school_website: "www.winidealschool.edu",
    school_whatsapp: "+1 (555) 987-6543",
  });

  useEffect(() => {
    const fetchSettings = () => {
      fetch("/api/settings")
        .then((res) => res.json())
        .then((data) => {
          if (data && Object.keys(data).length > 0) {
            setSettings((prev) => ({ ...prev, ...data }));
          }
        })
        .catch((err) => console.error("Failed to fetch settings", err));
    };

    fetchSettings();

    window.addEventListener("settingsUpdated", fetchSettings);
    return () => window.removeEventListener("settingsUpdated", fetchSettings);
  }, []);

  return (
    <footer className="bg-slate-900 text-slate-300 py-8 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <h3 className="text-white text-lg font-bold mb-4">
              WIN Ideal School
            </h3>
            <p className="text-sm text-slate-400 max-w-sm">
              Empowering students with knowledge, character, and skills for a
              brighter future.
            </p>
          </div>

          <div className="col-span-1 md:col-span-2">
            <h4 className="text-white font-semibold mb-4">
              Contact Information
            </h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center space-x-3">
                <MapPin className="h-4 w-4 text-indigo-400" />
                <span>{settings.school_address}</span>
              </li>
              <li className="flex items-center space-x-3">
                <Phone className="h-4 w-4 text-indigo-400" />
                <span>{settings.school_phone}</span>
              </li>
              <li className="flex items-center space-x-3">
                <Globe className="h-4 w-4 text-indigo-400" />
                <a
                  href={`https://${settings.school_website.replace(/^https?:\/\//, "")}`}
                  className="hover:text-white transition-colors"
                >
                  {settings.school_website}
                </a>
              </li>
              <li className="flex items-center space-x-3">
                <MessageCircle className="h-4 w-4 text-green-400" />
                <span>WhatsApp: {settings.school_whatsapp}</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-slate-800 text-center text-sm text-slate-500">
          <p>
            &copy; {new Date().getFullYear()} WIN Ideal School. All rights
            reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
