import Database from "better-sqlite3";
import path from "path";

const dbPath = path.resolve(process.cwd(), "school.db");
const db = new Database(dbPath);

// Initialize database
db.exec(`
  CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    rollNumber TEXT UNIQUE NOT NULL,
    grade TEXT NOT NULL,
    section TEXT NOT NULL,
    phone TEXT,
    address TEXT,
    subject TEXT DEFAULT 'General',
    totalMarks INTEGER DEFAULT 100,
    score INTEGER DEFAULT 0,
    photo TEXT
  );

  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS subjects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL
  );

  CREATE TABLE IF NOT EXISTS student_scores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    subject_id INTEGER NOT NULL,
    score INTEGER NOT NULL,
    total_marks INTEGER NOT NULL,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
  );
`);

try {
  db.exec("ALTER TABLE students ADD COLUMN subject TEXT DEFAULT 'General'");
  db.exec("ALTER TABLE students ADD COLUMN totalMarks INTEGER DEFAULT 100");
  db.exec("ALTER TABLE students ADD COLUMN score INTEGER DEFAULT 0");
  db.exec("ALTER TABLE students ADD COLUMN photo TEXT");
} catch (e) {
  // Columns likely already exist
}

// Insert some dummy data if empty
const count = db.prepare("SELECT COUNT(*) as count FROM students").get() as {
  count: number;
};
if (count.count === 0) {
  const insert = db.prepare(
    "INSERT INTO students (name, rollNumber, grade, section, phone, address, subject, totalMarks, score, photo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
  );
  insert.run(
    "John Doe",
    "1001",
    "10",
    "A",
    "555-0101",
    "123 Main St",
    "Science",
    100,
    85,
    "https://picsum.photos/seed/john/200/200",
  );
  insert.run(
    "Jane Smith",
    "1002",
    "10",
    "A",
    "555-0102",
    "456 Oak Ave",
    "Math",
    100,
    35,
    "https://picsum.photos/seed/jane/200/200",
  );
  insert.run(
    "Bob Johnson",
    "1003",
    "9",
    "B",
    "555-0103",
    "789 Pine Rd",
    "English",
    100,
    92,
    "https://picsum.photos/seed/bob/200/200",
  );
}

const settingsCount = db
  .prepare("SELECT COUNT(*) as count FROM settings")
  .get() as {
  count: number;
};
if (settingsCount.count === 0) {
  const insertSetting = db.prepare(
    "INSERT INTO settings (key, value) VALUES (?, ?)",
  );
  insertSetting.run(
    "school_address",
    "123 Education Avenue, Knowledge City, 10001",
  );
  insertSetting.run("school_phone", "+1 (555) 123-4567");
  insertSetting.run("school_website", "www.winidealschool.edu");
  insertSetting.run("school_whatsapp", "+1 (555) 987-6543");
}

// Initial subjects
const subjectsCount = db
  .prepare("SELECT COUNT(*) as count FROM subjects")
  .get() as { count: number };
if (subjectsCount.count === 0) {
  const insertSubject = db.prepare("INSERT INTO subjects (name) VALUES (?)");
  ["Math", "Science", "English", "History", "Geography"].forEach((s) =>
    insertSubject.run(s),
  );
}

// Initial scores for existing students
const scoresCount = db
  .prepare("SELECT COUNT(*) as count FROM student_scores")
  .get() as { count: number };
if (scoresCount.count === 0) {
  const students = db.prepare("SELECT id FROM students").all() as {
    id: number;
  }[];
  const subjects = db.prepare("SELECT id FROM subjects").all() as {
    id: number;
  }[];
  const insertScore = db.prepare(
    "INSERT INTO student_scores (student_id, subject_id, score, total_marks) VALUES (?, ?, ?, ?)",
  );

  students.forEach((student) => {
    subjects.forEach((subject) => {
      // Random scores for dummy data
      const score = Math.floor(Math.random() * 40) + 60;
      insertScore.run(student.id, subject.id, score, 100);
    });
  });
}

export default db;
