import React, { createContext, useContext, useState, ReactNode } from "react";

type User = {
  role: "admin" | "student";
  student?: {
    id: number;
    name: string;
    rollNumber: string;
    grade: string;
    section: string;
    phone: string;
    address: string;
    photo?: string;
  scores: {
      subject_id: number;
      subjectName: string;
      score: number;
      total_marks: number;
    }[];
  };
} | null;

interface AuthContextType {
  user: User;
  login: (userData: User) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User>(() => {
    const saved = localStorage.getItem("auth_user");
    return saved ? JSON.parse(saved) : null;
  });

  const login = (userData: User) => {
    setUser(userData);
    localStorage.setItem("auth_user", JSON.stringify(userData));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("auth_user");
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
