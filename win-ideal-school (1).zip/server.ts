import express from "express";
import { createServer as createViteServer } from "vite";
import db from "./src/db/index.js";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.post("/api/auth/admin", (req, res) => {
    const { password } = req.body;
    // Hardcoded admin password for simplicity
    if (password === "admin123") {
      res.json({ success: true, role: "admin" });
    } else {
      res.status(401).json({ error: "Invalid admin password" });
    }
  });

  app.post("/api/auth/student", (req, res) => {
    const { rollNumber } = req.body;
    const student = db
      .prepare("SELECT * FROM students WHERE rollNumber = ?")
      .get(rollNumber) as any;
    if (student) {
      const scores = db
        .prepare(
          `
        SELECT ss.*, s.name as subjectName 
        FROM student_scores ss 
        JOIN subjects s ON ss.subject_id = s.id 
        WHERE ss.student_id = ?
      `,
        )
        .all(student.id);
      res.json({
        success: true,
        role: "student",
        student: { ...student, scores },
      });
    } else {
      res.status(401).json({ error: "Student not found" });
    }
  });

  // Admin routes
  app.get("/api/students", (req, res) => {
    const { search } = req.query;
    let students;
    if (search) {
      students = db
        .prepare(
          "SELECT * FROM students WHERE name LIKE ? OR rollNumber LIKE ? ORDER BY name ASC",
        )
        .all(`%${search}%`, `%${search}%`) as any[];
    } else {
      students = db
        .prepare("SELECT * FROM students ORDER BY name ASC")
        .all() as any[];
    }

    const studentsWithScores = students.map((student) => {
      const scores = db
        .prepare(
          `
        SELECT ss.*, s.name as subjectName 
        FROM student_scores ss 
        JOIN subjects s ON ss.subject_id = s.id 
        WHERE ss.student_id = ?
      `,
        )
        .all(student.id);
      return { ...student, scores };
    });

    res.json(studentsWithScores);
  });

  app.post("/api/students", (req, res) => {
    const {
      name,
      rollNumber,
      grade,
      section,
      phone,
      address,
      photo,
      scores, // Array of { subjectName, score, total_marks }
    } = req.body;
    try {
      const info = db.transaction(() => {
        const stmt = db.prepare(
          "INSERT INTO students (name, rollNumber, grade, section, phone, address, photo) VALUES (?, ?, ?, ?, ?, ?, ?)",
        );
        const result = stmt.run(
          name,
          rollNumber,
          grade,
          section,
          phone,
          address,
          photo,
        );
        const studentId = result.lastInsertRowid;

        if (scores && Array.isArray(scores)) {
          const findSubject = db.prepare("SELECT id FROM subjects WHERE name = ?");
          const createSubject = db.prepare("INSERT INTO subjects (name) VALUES (?)");
          const scoreStmt = db.prepare(
            "INSERT INTO student_scores (student_id, subject_id, score, total_marks) VALUES (?, ?, ?, ?)",
          );
          const allStudents = db.prepare("SELECT id FROM students").all() as { id: number }[];

          for (const s of scores) {
            let subject = findSubject.get(s.subjectName) as { id: number } | undefined;
            if (!subject) {
              const res = createSubject.run(s.subjectName);
              const newSubjectId = res.lastInsertRowid as number;
              subject = { id: newSubjectId };
              
              // Add this new subject to ALL OTHER students too
              for (const otherStudent of allStudents) {
                if (otherStudent.id !== studentId) {
                  scoreStmt.run(otherStudent.id, newSubjectId, 0, 100);
                }
              }
            }
            scoreStmt.run(studentId, subject.id, s.score, s.total_marks);
          }
        }
        return { id: studentId };
      })();

      res.json({
        id: info.id,
        name,
        rollNumber,
        grade,
        section,
        phone,
        address,
        photo,
        scores,
      });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/students/:id", (req, res) => {
    const { id } = req.params;
    const student = db.prepare("SELECT * FROM students WHERE id = ?").get(id) as
      | any
      | undefined;
    if (!student) {
      return res.status(404).json({ error: "Student not found" });
    }

    const scores = db
      .prepare(
        `
      SELECT ss.*, s.name as subjectName 
      FROM student_scores ss
      JOIN subjects s ON ss.subject_id = s.id
      WHERE ss.student_id = ?
    `,
      )
      .all(id);

    res.json({ ...student, scores });
  });

  app.put("/api/students/:id", (req, res) => {
    const { id } = req.params;
    const { name, rollNumber, grade, section, phone, address, photo, scores } =
      req.body;
    try {
      db.transaction(() => {
        const stmt = db.prepare(
          "UPDATE students SET name = ?, rollNumber = ?, grade = ?, section = ?, phone = ?, address = ?, photo = ? WHERE id = ?",
        );
        stmt.run(name, rollNumber, grade, section, phone, address, photo, id);

        if (scores && Array.isArray(scores)) {
          // Delete old scores
          db.prepare("DELETE FROM student_scores WHERE student_id = ?").run(id);
          
          const findSubject = db.prepare("SELECT id FROM subjects WHERE name = ?");
          const createSubject = db.prepare("INSERT INTO subjects (name) VALUES (?)");
          const scoreStmt = db.prepare(
            "INSERT INTO student_scores (student_id, subject_id, score, total_marks) VALUES (?, ?, ?, ?)",
          );
          const allStudents = db.prepare("SELECT id FROM students").all() as { id: number }[];

          for (const s of scores) {
            let subject = findSubject.get(s.subjectName) as { id: number } | undefined;
            if (!subject) {
              const res = createSubject.run(s.subjectName);
              const newSubjectId = res.lastInsertRowid as number;
              subject = { id: newSubjectId };

              // Add this new subject to ALL OTHER students too
              for (const otherStudent of allStudents) {
                if (otherStudent.id !== Number(id)) {
                  scoreStmt.run(otherStudent.id, newSubjectId, 0, 100);
                }
              }
            }
            scoreStmt.run(id, subject.id, s.score, s.total_marks);
          }
        }
      })();
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/students/:id", (req, res) => {
    const { id } = req.params;
    try {
      db.transaction(() => {
        db.prepare("DELETE FROM student_scores WHERE student_id = ?").run(id);
        db.prepare("DELETE FROM students WHERE id = ?").run(id);
      })();
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Subject routes
  app.get("/api/subjects", (req, res) => {
    const subjects = db
      .prepare("SELECT * FROM subjects ORDER BY name ASC")
      .all();
    res.json(subjects);
  });

  app.post("/api/subjects", (req, res) => {
    const { name } = req.body;
    try {
      const info = db.transaction(() => {
        const stmt = db.prepare("INSERT INTO subjects (name) VALUES (?)");
        const result = stmt.run(name);
        const subjectId = result.lastInsertRowid;

        // Automatically add this subject to all existing students
        const students = db.prepare("SELECT id FROM students").all() as {
          id: number;
        }[];
        const scoreStmt = db.prepare(
          "INSERT INTO student_scores (student_id, subject_id, score, total_marks) VALUES (?, ?, ?, ?)",
        );

        for (const student of students) {
          scoreStmt.run(student.id, subjectId, 0, 100);
        }

        return { id: subjectId };
      })();

      res.json({ id: info.id, name });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.put("/api/subjects/:id", (req, res) => {
    const { id } = req.params;
    const { name } = req.body;
    try {
      db.prepare("UPDATE subjects SET name = ? WHERE id = ?").run(name, id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/subjects/:id", (req, res) => {
    const { id } = req.params;
    try {
      db.prepare("DELETE FROM subjects WHERE id = ?").run(id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Settings routes
  app.get("/api/settings", (req, res) => {
    const settings = db.prepare("SELECT * FROM settings").all() as {
      key: string;
      value: string;
    }[];
    const settingsObj = settings.reduce(
      (acc, curr) => {
        acc[curr.key] = curr.value;
        return acc;
      },
      {} as Record<string, string>,
    );
    res.json(settingsObj);
  });

  app.put("/api/settings", (req, res) => {
    const settings = req.body;
    try {
      const insertStmt = db.prepare(
        "INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)",
      );
      db.transaction(() => {
        for (const [key, value] of Object.entries(settings)) {
          insertStmt.run(key, value as string);
        }
      })();
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static("dist"));
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
